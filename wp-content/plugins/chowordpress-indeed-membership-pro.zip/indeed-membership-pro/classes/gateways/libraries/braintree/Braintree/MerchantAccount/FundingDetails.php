<?php
namespace Braintree\MerchantAccount;

use Braintree\Instance;

class FundingDetails extends Instance
{
    protected $_attributes = [];
}
